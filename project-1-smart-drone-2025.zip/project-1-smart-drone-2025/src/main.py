from mapa import InterfazDronGUI

def main ():
    print('___________Running GUI___________')
    InterfazDronGUI()

if __name__ == "__main__":
    main()